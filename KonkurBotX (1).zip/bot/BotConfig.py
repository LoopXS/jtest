#All Credits Belong to @CipherXBot

import os
from os import getenv, environ
from dotenv import load_dotenv

load_dotenv()

class Config(object):
    BOT_TOKEN = str(getenv("BOT_TOKEN")) 
    SESSION = str(getenv("SESSION")) 
    XSESSION = str(getenv("XSESSION")) 
    REDIS_URI = str(getenv("REDIS_URI")) 
    REDIS_PASSWORD = str(getenv("REDIS_PASSWORD")) 
    FSUB = set(str(x) for x in getenv("FSUB", "").split())
    OWNER_ID = set(int(x) for x in getenv("OWNER_ID", "").split())
    COMMAND_HAND_LER = "^/"
    LOG_CHAT = int(getenv("LOG_CHAT"))
