#All Credits Belong to @CipherXBot

import re
import os
import asyncio
import logging
from datetime import datetime
 
from telethon import custom, events, Button
from telethon.tl import types
from telethon.utils import get_display_name
from telethon.tl.types import InputMessagesFilterDocument
from telethon.tl.functions.channels import GetParticipantRequest
from telethon.tl.types import (
    ChannelParticipant, 
    ChannelParticipantCreator, 
    ChannelParticipantAdmin, 
    ChannelParticipantBanned,
)
from telethon.errors import BadRequestError, UserNotParticipantError
from telethon.errors.rpcerrorlist import UserIdInvalidError

from bot.BotConfig import Config
from bot import botx, botcli, udB
from bot.utils import callback
from .base import KeyManager
from .chatdb import *

buttons= [
             [
                 Button.inline("⌔آزمون های آزمایشی⌔", data="azmoon"), 
                 Button.inline("⌔سوالات نهایی⌔", data="nahayi"),
             ],
             [
                 Button.inline("⌔بانک تست⌔", data="test"),
                 Button.inline("⌔سوالات کنکور⌔", data="soal"),
             ],
             [
                 Button.inline("⌔کتاب های کمک آموزشی⌔", data="ketab"),
                 Button.inline("⌔پشتیبانی و تبلیغات⌔", data="support"),
             ],
        ]

ownbut= [
             [
                 Button.inline("⌔آزمون های آزمایشی⌔", data="azmoon"), 
                 Button.inline("⌔سوالات نهایی⌔", data="nahayi"),
             ],
             [
                 Button.inline("⌔بانک تست⌔", data="test"), 
                 Button.inline("⌔سوالات کنکور⌔", data="soal"),
             ],
             [
                 Button.inline("⌔کتاب های کمک آموزشی⌔", data="ketab"),
                 Button.inline("⌔پشتیبانی و تبلیغات⌔", data="support"),
             ],
             [
                 Button.inline("⌔مدیریت⌔", data="manage"),
             ],
        ]

butaz= [
             [
                 Button.inline("تجربی", data="tajrobi"), 
                 Button.inline("ریاضی", data="riazi"),
                 Button.inline("انسانی", data="ensani"),
             ],
             [
                 Button.inline("بازگشت", data="return"),
             ], 
        ]

tajbs= [
             [
                 Button.inline("قلمچی", data="pentaj"), 
                 Button.inline("زیستاز", data="aztaj"),
                 Button.inline("ماز", data="maztaj"),
             ], 
             [
                 Button.inline("سنجش", data="santaj"),
                 Button.inline("گزینه دو (1403)", data="dotaj"),
             ],
             [
                 Button.inline("بازگشت", data="azmoon"),
             ], 
]

azbs= [
             [
                 Button.inline("قلمچی", data="penaz"),
                 Button.inline("ماز", data="mazaz"),
             ], 
             [
                 Button.inline("سنجش", data="sanaz"),
                 Button.inline("گزینه دو (1403)", data="doaz"),
             ],
             [
                 Button.inline("بازگشت", data="azmoon"),
             ], 
]

enbs= [
             [
                 Button.inline("قلمچی", data="penen"),
                 Button.inline("سنجش", data="sanen"),
             ],
             [
                 Button.inline("بازگشت", data="azmoon"),
             ], 
]

cbs= [
             [
                 Button.inline("آمار", data="stat"),
                 Button.inline("پیام همگانی", data="bcast"),
             ],
              [
                 Button.inline("بن", data="ban"),
                 Button.inline("آنبن", data="unban"),
             ],
             [
                 Button.inline("بازگشت", data="return"),
             ], 
]

def inline_mention(user, custom=None, html=False):
    mention_text = get_display_name(user) or "Deleted Account" if not custom else custom
    if isinstance(user, types.User):
        if html:
            return f"<a href=tg://user?id={user.id}>{mention_text}</a>"
        return f"[{mention_text}](tg://user?id={user.id})"
    if isinstance(user, types.Channel) and user.username:
        if html:
            return f"<a href=https://t.me/{user.username}>{mention_text}</a>"
        return f"[{mention_text}](https://t.me/{user.username})"
    return mention_text

async def is_member(user_id):
    for i in Config.FSUB:
        try:
            values = await botx(GetParticipantRequest(i, user_id))
            if isinstance(values.participant, ChannelParticipantBanned):
                return "FalseBanned"
            if isinstance(values.participant, ChannelParticipantCreator):
                return True
            if isinstance(values.participant, ChannelParticipantAdmin):
                return True
            if not isinstance(values.participant, ChannelParticipant):
                return False
        except UserNotParticipantError:
            return False
    return True

@botx_cmd("start", is_args=False)
async def start(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        fbut = []
        for i in Config.FSUB:
            txt = i.lstrip("@")
            fbut.append(
                Button.url(
                    f"{txt}", 
                    url=f"https://t.me/{txt}"
                ) 
            ) 
        await botx.send_message(
            event.chat_id, 
            f"لطفا برای استفاده از ربات، به چنل های زیر جوین شوید.", 
            buttons=fbut
        )
        fbut.clear()
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id)== True:
        keym = KeyManager("BOT_USERS", cast=list)
        if not keym.contains(event.sender_id) and event.sender_id not in Config.OWNER_ID:
            keym.add(event.sender_id)
        probot = await botx.get_me()
        bot_id = probot.first_name
        bot_username = probot.username
        mention = inline_mention(event.sender)
        msg = f"**✨ سلام {mention} عزیز، به ربات ساقی آزمون خوش آمدید** \n** 🤖 بر روی یکی از گزینه های زیر کلیک نمایید**"
        if user_id in Config.OWNER_ID:
            await botx.send_message(event.chat_id, msg, buttons=ownbut)
        else:
            await botx.send_message(event.chat_id, msg, buttons=buttons)

@callback("nahayi")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT):
            try:
                if "#سوالات_نهایی" in message.message:
                    await botx.send_message(event.chat_id, message.message, formatting_entities=message.entities, link_preview=False)
            except Exception as e:
                logging.info(f"Error: {str(e)}")


@callback("ketab")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT):
            try:
                if "#کمک_آموزشی" in message.message:
                    await botx.send_message(event.chat_id, message.message, formatting_entities=message.entities, link_preview=False)
            except Exception as e:
                logging.info(f"Error: {str(e)}")

@callback("soal")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT):
            try:
                if "#سوالات_کنکور" in message.message:
                    await botx.send_message(event.chat_id, message.message, formatting_entities=message.entities, link_preview=False)
            except Exception as e:
                logging.info(f"Error: {str(e)}")

@callback("test")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT):
            try:
                if "#بانک_تست" in message.message:
                    await botx.send_message(event.chat_id, message.message, formatting_entities=message.entities, link_preview=False)
            except Exception as e:
                logging.info(f"Error: {str(e)}")

@callback("azmoon")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨رشته تحصیلی خود را انتخاب کنید", 
                buttons=butaz,
            )
        except Exception as e:
            logging.info(e)

@callback("return")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        probot = await botx.get_me()
        bot_id = probot.first_name
        bot_username = probot.username
        mention = inline_mention(event.sender)
        msg = f"**سلام {mention} عزیز، به ربات ساقی آزمون خوش آمدید** \n** بر روی یکی از گزینه های زیر کلیک نمایید**"
        if user_id in Config.OWNER_ID:
            await event.edit(msg, buttons=ownbut)
        else:
            await event.edit(msg, buttons=buttons)

@callback("tajrobi")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨مؤسسه آموزشی را انتخاب کنید", 
                buttons=tajbs,
            )
        except Exception as e:
            logging.info(e)
            
#----------قلم چی تجربی----------#

@callback("pentaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨سال آموزشی را انتخاب کنید", 
                buttons=
                    [
                        [
                            Button.inline("98-99", data="99pentaj"), 
                            Button.inline("99-00", data="00pentaj"),
                            Button.inline("00-01", data="01pentaj"),
                        ], 
                        [
                            Button.inline("01-02", data="02pentaj"),
                            Button.inline("02-03", data="03pentaj"),
                        ],
                        [
                            Button.inline("بازگشت", data="tajrobi"),
                        ], 
                    ],
            )
        except Exception as e:
            logging.info(e)

@callback("99pentaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#99_تجربی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("00pentaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#00_تجربی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("01pentaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#01_تجربی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("02pentaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#02_تجربی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("03pentaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#03_تجربی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

#----------ماز تجربی----------#

@callback("maztaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨سال آموزشی را انتخاب کنید", 
                buttons=
                    [
                        [
                            Button.inline("98-99", data="99maztaj"),
                            Button.inline("99-00", data="00maztaj"),
                            Button.inline("00-01", data="01maztaj"),
                        ], 
                        [
                            Button.inline("01-02", data="02maztaj"),
                            Button.inline("02-03", data="03maztaj"),
                        ],
                        [
                            Button.inline("بازگشت", data="tajrobi"),
                        ], 
                    ],
            )
        except Exception as e:
            logging.info(e)

@callback("99maztaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#99_تجربی_ماز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return
                
@callback("00maztaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#00_تجربی_ماز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("01maztaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#01_تجربی_ماز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("02maztaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#02_تجربی_ماز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("03maztaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#03_تجربی_ماز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return
                
#----------زیستاز تجربی----------#

@callback("aztaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨سال آموزشی را انتخاب کنید", 
                buttons=
                    [
                        [
                            Button.inline("99-00", data="00aztaj"),
                            Button.inline("00-01", data="01aztaj"),
                        ], 
                        [
                            Button.inline("01-02", data="02aztaj"),
                            Button.inline("02-03", data="03aztaj"),
                        ],
                        [
                            Button.inline("بازگشت", data="tajrobi"),
                        ], 
                    ],
            )
        except Exception as e:
            logging.info(e)

@callback("00aztaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#00_تجربی_زیستاز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("01aztaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#01_تجربی_زیستاز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("02aztaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#02_تجربی_زیستاز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("03aztaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#03_تجربی_زیستاز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

#----------سنجش تجربی----------#

@callback("santaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨سال آموزشی را انتخاب کنید", 
                buttons=
                    [
                        [
                            Button.inline("98-99", data="99santaj"),
                            Button.inline("99-00", data="00santaj"),
                            Button.inline("00-01", data="01santaj"),
                        ], 
                        [
                            Button.inline("01-02", data="02santaj"),
                            Button.inline("02-03", data="03santaj"),
                        ],
                        [
                            Button.inline("بازگشت", data="tajrobi"),
                        ], 
                    ],
            )
        except Exception as e:
            logging.info(e)

@callback("99santaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#99_تجربی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return
                
@callback("00santaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#00_تجربی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("01santaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#01_تجربی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("02santaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#02_تجربی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("03santaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#03_تجربی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

#----------گزینه دو تجربی----------#

@callback("dotaj")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#03_تجربی_گزینه2" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("riazi")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨مؤسسه آموزشی را انتخاب کنید", 
                buttons=azbs,
            )
        except Exception as e:
            logging.info(e)
            
#----------قلم چی ریاضی----------#

@callback("penaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨سال آموزشی را انتخاب کنید", 
                buttons=
                    [
                        [
                            Button.inline("98-99", data="99penaz"), 
                            Button.inline("99-00", data="00penaz"),
                            Button.inline("00-01", data="01penaz"),
                        ], 
                        [
                            Button.inline("01-02", data="02penaz"),
                            Button.inline("02-03", data="03penaz"),
                        ],
                        [
                            Button.inline("بازگشت", data="riazi"),
                        ], 
                    ],
            )
        except Exception as e:
            logging.info(e)

@callback("99penaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#99_ریاضی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("00penaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#00_ریاضی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("01penaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#01_ریاضی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("02penaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#02_ریاضی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("03penaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#03_ریاضی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

#----------ماز ریاضی----------#

@callback("mazaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨سال آموزشی را انتخاب کنید", 
                buttons=
                    [
                        [
                            Button.inline("99-00", data="00mazaz"),
                            Button.inline("00-01", data="01mazaz"),
                        ], 
                        [
                            Button.inline("01-02", data="02mazaz"),
                            Button.inline("02-03", data="03mazaz"),
                        ],
                        [
                            Button.inline("بازگشت", data="riazi"),
                        ], 
                    ],
            )
        except Exception as e:
            logging.info(e)
                
@callback("00mazaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#00_ریاضی_ماز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("01mazaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#01_ریاضی_ماز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("02mazaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#02_ریاضی_ماز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("03mazaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#03_ریاضی_ماز" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

#----------سنجش ریاضی----------#

@callback("sanaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨سال آموزشی را انتخاب کنید", 
                buttons=
                    [
                        [
                            Button.inline("98-99", data="99sanaz"), 
                            Button.inline("99-00", data="00sanaz"),
                            Button.inline("00-01", data="01sanaz"),
                        ], 
                        [
                            Button.inline("01-02", data="02sanaz"),
                            Button.inline("02-03", data="03sanaz"),
                        ],
                        [
                            Button.inline("بازگشت", data="riazi"),
                        ], 
                    ],
            )
        except Exception as e:
            logging.info(e)

@callback("99sanaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#99_ریاضی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("00sanaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#00_ریاضی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return
                
@callback("01sanaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#01_ریاضی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("02sanaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#02_ریاضی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("03sanaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#03_ریاضی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

#----------گزینه دو ریاضی----------#

@callback("doaz")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#03_ریاضی_گزینه2" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("ensani")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨مؤسسه آموزشی را انتخاب کنید", 
                buttons=enbs,
            )
        except Exception as e:
            logging.info(e)

#----------قلم چی انسانی----------#

@callback("penen")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨سال آموزشی را انتخاب کنید", 
                buttons=
                    [
                        [
                            Button.inline("98-99", data="99penen"), 
                            Button.inline("99-00", data="00penen"),
                            Button.inline("00-01", data="01penen"),
                        ], 
                        [
                            Button.inline("01-02", data="02penen"),
                            Button.inline("02-03", data="03penen"),
                        ],
                        [
                            Button.inline("بازگشت", data="ensani"),
                        ], 
                    ],
            )
        except Exception as e:
            logging.info(e)

@callback("99penen")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#99_انسانی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return
                
@callback("00penen")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#00_انسانی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("01penen")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#01_انسانی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("02penen")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#02_انسانی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("03penen")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#03_انسانی_قلمچی" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

#----------قلم چی انسانی----------#

@callback("sanen")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "✨سال آموزشی را انتخاب کنید", 
                buttons=
                    [
                        [
                            Button.inline("98-99", data="99sanen"), 
                            Button.inline("99-00", data="00sanen"),
                            Button.inline("00-01", data="01sanen"),
                        ], 
                        [
                            Button.inline("01-02", data="02sanen"),
                            Button.inline("02-03", data="03sanen"),
                        ],
                        [
                            Button.inline("بازگشت", data="ensani"),
                        ], 
                    ],
            )
        except Exception as e:
            logging.info(e)

@callback("99sanen")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#99_انسانی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("00sanen")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#00_انسانی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("01sanen")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#01_انسانی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("02sanen")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#02_انسانی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("03sanen")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        async for message in botcli.iter_messages(Config.LOG_CHAT, filter=InputMessagesFilterDocument):
            try:
                if ".pdf" in message.document.attributes[0].file_name:
                    if "#03_انسانی_سنجش" in message.message:
                        try:
                            file = await botcli.download_media(message.document)
                            await botx.send_file(event.chat_id, file)
                            os.remove(file)
                        except Exception as e:
                            logging.info(e)
            except AttributeError:
                return

@callback("manage")
async def catcher(event):
    user_id = int(event.sender.id)
    if await is_member(user_id) == False:
        await botx.send_message(event.chat_id, f"لطفا برای استفاده از ربات، به چنل {Config.FSUB} جوین شوید.")
    if await is_member(user_id) == "FalseBanned":
        await botx.send_message(event.chat_id, "شما بن شده اید و نمی توانید از ربات استفاده نمایید.")
    if await is_member(user_id) == True:
        try:
            await event.edit(
                "⚜️یکی از گزینه های مدیریتی زیر را انتخاب کنید", 
                buttons=cbs,
            )
        except Exception as e:
            logging.info(e)

@callback("stat", owner=True)
async def botstat(event):
    ok = len(udB.get_key("BOT_USERS") or [])
    msg = """✨آمار ربات ساقی آزمون
⚜️تعداد کل کاربران - {}""".format(
        ok,
    )
    await event.answer(msg, cache_time=0, alert=True)

@callback("bcast", owner=True)
async def bdcast(event):
    user_id = int(event.sender.id)
    keym = KeyManager("BOT_USERS", cast=list)
    total = keym.count()
    try:
        async with botx.conversation(user_id) as conv:
            await conv.send_message("متن پیام همگانی خود را وارد نمایید.\nبرای لغو کامند /cancel را بزنید.")
            response = await conv.get_response()
            resp = response.raw_text
            if resp == "/cancel":
                return await conv.send_message("فرایند با موفقیت کنسل شد.")
            success = 0
            fail = 0
            await conv.send_message(f"شروع ارسال پیام همگانی به {total} کاربر...")
            start = datetime.now()
            for i in keym.get():
                try:
                    await botx.send_message(int(i), resp)
                    success += 1
                except BaseException:
                    fail += 1
            end = datetime.now()
            time_taken = (end - start).seconds
            await conv.send_message(
                f"""
                **پیام همگانی به مدت {time_taken} ثانیه به طول انجامید.**
                تعداد کل کاربران بات- {total}
                **ارسال موفق** : `{success}` کاربر.
                **ارسال ناموفق** : `{fail}` کاربر.""",
            )
    except Exception as e:
        logging.info(e)

@callback("support")
async def support(event):
    user_id = int(event.sender.id)
    try:
        async with botx.conversation(event.chat_id) as conv:
            await conv.send_message("✨لطفا پیام خود را ارسال نمایید.\nبرای لغو کامند /cancel را بزنید.")
            response = await conv.get_response()
            resp = response.raw_text
            if resp:
                if resp == "/cancel":
                    return await conv.send_message("فرایند با موفقیت کنسل شد.")
                else:
                    try:
                        for i in Config.OWNER_ID:
                            await botx.send_message(
                                int(i),
                                resp, 
                                buttons =
                                    [
                                        [
                                            Button.inline("⌔ پاسخ ⌔", data=f"ans:{response.id}"),
                                        ],
                                    ],
                            )
                        add_stuff(response.id, user_id)
                        await conv.send_message(f"پیام شما با موفقیت ارسال شد. منتظر دریافت پاسخ بمانید.")
                    except Exception as e:
                        logging.info(e)
    except Exception as e:
        logging.info(e)

@callback(
    re.compile(
        "ans:(.*)",
    ),
    owner=True,
)
async def ans(event):
    _e = event.pattern_match.group(1).strip().decode("UTF-8")
    rawl = _e.split(":")
    idx = rawl[0]
    to_user = get_who(int(idx))
    if to_user:
        try:
            async with botx.conversation(event.chat_id) as conv:
                await conv.send_message("لطفا پیام خود را برای این کاربر ارسال نمایید.\nبرای لغو کامند /cancel را بزنید.")
                response = await conv.get_response()
                resp = response.raw_text
                if resp:
                    if resp == "/cancel":
                        return await conv.send_message("فرایند با موفقیت کنسل شد.")
                    else:
                        try:
                            await botx.send_message(
                                to_user,
                                resp,
                            )
                            await conv.send_message(f"پیام شما با موفقیت ارسال شد.")
                        except Exception as e:
                            logging.info(e)
        except Exception as e:
            logging.info(e)

@callback("ban")
async def ban(event):
    user_id = int(event.sender.id)
    try:
        async with botx.conversation(event.chat_id) as conv:
            await conv.send_message("لطفا آیدی عددی فرد مورد نظر را ارسال نمایید.\nبرای لغو کامند /cancel را بزنید.")
            response = await conv.get_response()
            resp = response.raw_text
            if resp:
                if resp == "/cancel":
                    return await conv.send_message("فرایند با موفقیت کنسل شد.")
                if resp.isnumeric() is False:
                    return await conv.send_message("تنها آیدی عددی وارد نمایید!")
                else:
                    try:
                        for i in Config.FSUB:
                            await botx.edit_permissions(i, int(resp), view_messages=False)
                        await conv.send_message("کاربر با موفقیت بن شد.")
                    except UserIdInvalidError:
                        return await conv.send_message("آیدی نامعتبر می باشد!")
                    except BadRequestError:
                        return await conv.send_message("ربات دارای دسترسی بن در چنل جوین اجباری نمی باشد!")
                    except Exception as e:
                        logging.info(e)
    except Exception as e:
        logging.info(e)

@callback("unban")
async def unban(event):
    user_id = int(event.sender.id)
    try:
        async with botx.conversation(event.chat_id) as conv:
            await conv.send_message("لطفا آیدی عددی فرد مورد نظر را ارسال نمایید.\nبرای لغو کامند /cancel را بزنید.")
            response = await conv.get_response()
            resp = response.raw_text
            if resp:
                if resp == "/cancel":
                    return await conv.send_message("فرایند با موفقیت کنسل شد.")
                if resp.isnumeric() is False:
                    return await conv.send_message("تنها آیدی عددی وارد نمایید!")
                else:
                    try:
                        for i in Config.FSUB:
                            await botx.edit_permissions(i, int(resp), view_messages=True)
                        await conv.send_message("کاربر با موفقیت آنبن شد.")
                    except UserIdInvalidError:
                        return await conv.send_message("آیدی نامعتبر می باشد!")
                    except BadRequestError:
                        return await conv.send_message("ربات دارای دسترسی آنبن در چنل جوین اجباری نمی باشد!")
                    except Exception as e:
                        logging.info(e)
    except Exception as e:
        logging.info(e)
