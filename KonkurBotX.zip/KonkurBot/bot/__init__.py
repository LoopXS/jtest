#All Credits Belong to @CipherXBot

import asyncio
import glob
import os
import time
import sys
from pathlib import Path
from sys import argv
import logging

import telethon.utils
from telethon import TelegramClient, events, functions, types
from telethon.sessions import StringSession

from bot.database import CipherXDB

ENV = os.environ.get("ENV", True)

if ENV:
    from bot.BotConfig import Config
    
logging.basicConfig(
    level=logging.WARNING,
    datefmt="%d/%m/%Y %H:%M:%S",
    format="[%(asctime)s][%(name)s][%(levelname)s] ==> %(message)s",
    handlers=[logging.StreamHandler(stream=sys.stdout),
              logging.FileHandler("botx.log", mode="a", encoding="utf-8")],)

logging.getLogger("telethon").setLevel(logging.ERROR)

botx = TelegramClient("thebotx", api_id=6, api_hash="eb06d4abfb49dc3eeb1aeb98ae0f581e")

botcli = TelegramClient(StringSession(Config.SESSION), api_id=21724, api_hash="3e0cb5efcd52300aec5994fdfc5bdc16")


if Config.BOT_TOKEN is None:
    logging.info("BOT_TOKEN is None. Bot is Quiting...")
    sys.exit(1)
if Config.OWNER_ID is None:
    logging.info("OWNER_ID is None. Please Add Your ID to Continue.")
    sys.exit(1)
if Config.LOG_CHAT is None:
    logging.info("Add LOG_CHAT For This Bot to Work")
    sys.exit(1)
    
udB = CipherXDB()
