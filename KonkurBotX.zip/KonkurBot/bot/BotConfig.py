#All Credits Belong to @CipherXBot

import os

class Config(object):
    BOT_TOKEN = os.environ.get("BOT_TOKEN", None)
    SESSION = os.environ.get("SESSION", None)
    XSESSION = os.environ.get("XSESSION", None)
    REDIS_URI = os.environ.get("REDIS_URI", None)
    REDIS_PASSWORD = os.environ.get("REDIS_PASSWORD", None)
    FSUB = set(str(x) for x in os.environ.get("FSUB", "").split())
    OWNER_ID = set(int(x) for x in os.environ.get("OWNER_ID", "").split())
    COMMAND_HAND_LER = os.environ.get("COMMAND_HAND_LER", "^/")
    LOG_CHAT = int(os.environ.get("LOG_CHAT", False))
